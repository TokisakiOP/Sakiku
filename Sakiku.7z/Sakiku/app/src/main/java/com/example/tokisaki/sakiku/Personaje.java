package com.example.tokisaki.sakiku;

/**
 * Created by Tokisaki on 15/04/2018.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/***
 * Clase que gestiona loe elementos relacionados con el personaje que controlamos
 */
public class Personaje {

    private Context context; // contexto de la aplicación
    private int numImagenes_quieto = 9; // número de frames de la acción estar quieto
    private int numImagenes_shoot = 4; // número de frames de la acción disparar horizontalmente
    private int numImagenes_up = 8; // número de frames de la acción disparar verticalmente
    private int numImagenes_run = 9; // número de frames de la acción moverse horizontalmente
    private int numImagenes_dead = 10; // número de frames de la acción morirse
    private int numImagenesH_run = 3; // numero de frames horizontales a recortar de la accion moverse horizontalmente
    private int numImagenesV_run = 3; // numero de frames verticales a recortar de la accion moverse horizontalmente
    private int numImagenesH_dead = 3; // numero de frames horizontales a recortar de la accion morirse
    private int numImagenesV_dead = 4; // numero de frames verticales a recortar de la accion morirse
    private int numImagenesH_shoot = 2; // numero de frames horizontales a recortar de la accion disparar horizontalmente
    private int numImagenesV_shoot = 2; // numero de frames verticales a recortar de la accion disparar horizontalmente
    private int numImagenesH_up = 3; // numero de frames horizontales a recortar de la accion disparar verticalmente
    private int numImagenesV_up = 3; // numero de frames verticales a recortar de la accion disparar verticalmente
    private int numImagenesH_quieto = 3; // numero de frames horizontales a recortar de la accion estar quieto
    private int numImagenesV_quieto = 3; // numero de frames verticales a recortar de la accion estar quieto
    private int anchoFrame; // ancho del frame a recortar
    private int altoFrame; // alto del frame a recortar
    private int cambioH = 0; // cambia la columna del recorte del frame
    private int cambioV = 0; // cambia la fila del recorte del frame
    protected int posX=0; // posicion en el eje X donde esta situado el personaje
    protected int suelo; // limite Y donde pisa el personaje
    protected int numFrame; // numero del frame actual
    protected int alto; // alto del cuadrado de colisión
    private int ancho; // ancho del cuadrado de colisión
    private Bitmap[] movimientoX; // lista con los frames de la accion movimiento horizontal
    // private Bitmap[] movimientoBack; // lista con los frames de la accion movimiento horizontal aplicando espejo
    private Bitmap[] movimientoDead; // lista con los frames de la accion muerte
    // private Bitmap[] movimientoMuerte; // lista con los frames de la accion muerte aplicando espejo
    private Bitmap[] movimientoShoot; // lista con los frames de la accion disparo horizontal
    // private Bitmap[] movimientoDisparo; // lista con los frames de la accion disparo horizontal aplicando espejo
    private Bitmap[] movimientoUp; // lista con los frames de la accion disparo vertical
    // private Bitmap[] movimientoArriba; // lista con los frames de la accion disparo vertical aplicando espejo
    // private Bitmap[] movimientoStill; // lista con los frames de la accion estar quieto aplicando espejo
    private Bitmap[] movimientoQuieto; // lista con los frames de la accion estar quieto
    private Bitmap movimientoLateral; // frame con el recorte actual de movimiento horizontal
    private Bitmap dead; // frame con el recorte actual de movimiento muerte
    private Bitmap shoot; // frame con el recorte actual de disparo horizontal
    private Bitmap quieto; // frame con el recorte actual de estar quieto
    private Bitmap up; // frame con el recorte actual de disparo vertical
    protected RectF[] rectangulos; // Array con los cuadrados de colisión
    private boolean parado = false; // booleano que indica si el personaje esta parado
    protected boolean muriendo; // booleano que indica si el personaje esta en la acción de morirse


    public Personaje(Context context,int altoPantalla){
        this.context =context;
        rectangulos = new RectF[2];
        suelo = altoPantalla;
        inicializarElementos();
    }

    /***
     * Función que inicializa los elementos necesarios en la clase
     */
    public void inicializarElementos(){
        movimientoX = new Bitmap[numImagenes_run];
        // movimientoBack = new Bitmap[numImagenes_run];
        movimientoDead = new Bitmap[numImagenes_dead];
        // movimientoMuerte = new Bitmap[numImagenes_dead];
        movimientoShoot = new Bitmap[numImagenes_shoot];
        // movimientoDisparo = new Bitmap[numImagenes_shoot];
        movimientoUp = new Bitmap[numImagenes_up];
        // movimientoArriba = new Bitmap[numImagenes_up];
        movimientoQuieto = new Bitmap[numImagenes_quieto];
        // movimientoStill = new Bitmap[numImagenes_quieto];
        movimientoLateral = BitmapFactory.decodeResource(context.getResources(),R.drawable.run);
        anchoFrame = movimientoLateral.getWidth() / numImagenesH_run;
        altoFrame = movimientoLateral.getHeight() / numImagenesV_run;
        for(int i = 0; i < numImagenes_run; i++){
            Bitmap frame = Bitmap.createBitmap(movimientoLateral,cambioH*anchoFrame,cambioV*altoFrame,anchoFrame,altoFrame);;
            frame = escalaAltura(frame,getPixels(100));
            movimientoX[i]=frame;
            //   movimientoBack[i] = espejo(frame,true);
            cambioH++;
            if(i==2||i==5){
                cambioH=0;
                cambioV++;
            }
        }
        movimientoLateral = null;
        dead = BitmapFactory.decodeResource(context.getResources(),R.drawable.dead);
        cambioH = 0; cambioV = 0;
        anchoFrame = dead.getWidth() / numImagenesH_dead;
        altoFrame = dead.getHeight() / numImagenesV_dead;
        for(int i = 0; i < numImagenes_dead; i++){
            Bitmap frame = Bitmap.createBitmap(dead,cambioH*anchoFrame,cambioV*altoFrame,anchoFrame,altoFrame);;
            frame = escalaAltura(frame,getPixels(100));
            movimientoDead[i]=frame;
            // movimientoMuerte[i]=frame;
            cambioH++;
            if(i==2||i==5 || i ==8){
                cambioH=0;
                cambioV++;
            }
        }
        dead = null;
        shoot = BitmapFactory.decodeResource(context.getResources(),R.drawable.disparo);
        cambioH = 0; cambioV = 0;
        anchoFrame = shoot.getWidth() / numImagenesH_shoot;
        altoFrame = shoot.getHeight() / numImagenesV_shoot;
        for(int i = 0; i < numImagenes_shoot; i++){
            Bitmap frame = Bitmap.createBitmap(shoot,cambioH*anchoFrame,cambioV*altoFrame,anchoFrame,altoFrame);;
            frame = escalaAltura(frame,getPixels(100));
            movimientoShoot[i]=frame;
            //movimientoDisparo[i] = frame;
            cambioH++;
            if(i==1){
                cambioH=0;
                cambioV++;
            }
        }
        shoot = null;
        up = BitmapFactory.decodeResource(context.getResources(),R.drawable.disparo_up);
        cambioH = 0; cambioV = 0;
        anchoFrame = up.getWidth() / numImagenesH_up;
        altoFrame = up.getHeight() / numImagenesV_up;
        for(int i = 0; i < numImagenes_up; i++){
            Bitmap frame = Bitmap.createBitmap(up,cambioH*anchoFrame,cambioV*altoFrame,anchoFrame,altoFrame);;
            frame = escalaAltura(frame,getPixels(100));
            movimientoUp[i]=frame;
            //movimientoArriba[i]=frame;
            cambioH++;
            if(i==2 || i==5){
                cambioH=0;
                cambioV++;
            }
        }
        up = null;
        quieto = BitmapFactory.decodeResource(context.getResources(),R.drawable.quieto);
        cambioH = 0; cambioV = 0;
        anchoFrame = quieto.getWidth() / numImagenesH_quieto;
        altoFrame = quieto.getHeight() / numImagenesV_quieto;
        for(int i = 0; i < numImagenes_quieto; i++){
            Bitmap frame = Bitmap.createBitmap(quieto,cambioH*anchoFrame,cambioV*altoFrame,anchoFrame,altoFrame);;
            frame = escalaAltura(frame,getPixels(100));
            movimientoQuieto[i]=frame;
            // movimientoStill[i] = espejo(frame,true);
            cambioH++;
            if(i==2 || i==5){
                cambioH=0;
                cambioV++;
            }
        }
        quieto = null;
    }

    /***
     * Reescala una imagen
     * @param bitmapAux imagen a reescalar
     * @param nuevoAlto nuevo alto de la imagen despues del rescalado
     * @return la imagen reescalada
     */
    public Bitmap escalaAltura(Bitmap bitmapAux, int nuevoAlto ) {
        if (nuevoAlto==bitmapAux.getHeight()) return bitmapAux;
        return bitmapAux.createScaledBitmap(bitmapAux, (bitmapAux.getWidth() * nuevoAlto) / bitmapAux.getHeight(),
                nuevoAlto, true);
    }

    /***
     * Transforma pixeles en dps
     * @param dp dps a transformar
     * @return dp transformados
     */
    int getPixels(float dp) {
        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().
                getMetrics(metrics);
        return (int)(dp*metrics.density);
    }

    /***
     * Función que aplica visión de espejo a una imagen
     * @param imagen imagen a aplicar la visión
     * @param horizontal Booleano que indica si se plicara vertical o horizontalmente
     * @return imagen transformada
     */
    public Bitmap espejo(Bitmap imagen, Boolean horizontal){
        Matrix matrix = new Matrix();
        if (horizontal) matrix.preScale(-1, 1);
        else matrix.preScale(1, -1);
        return Bitmap.createBitmap(imagen, 0, 0, imagen.getWidth(),
                imagen.getHeight(), matrix, false);
    }

    /***
     * Función que actualiza los rectangulos de colisión
     * @param array String que indica que accion se esta ejecutando
     */
    private void setRectangulos(String array) {
        switch (array){
            case "movimientoX":
                ancho = movimientoX[numFrame].getWidth();
                alto = movimientoX[numFrame].getHeight();
                parado=  false;;
                break;
            case "movimientoXespejo":
                ancho = espejo(movimientoX[numFrame],true).getWidth();
                alto = espejo(movimientoX[numFrame],true).getHeight();
                parado = false;
                break;
            case "quieto":
                ancho = movimientoQuieto[numFrame].getWidth();
                alto = movimientoQuieto[numFrame].getHeight();
                parado = true;
                break;
            case "shoot":
                ancho = espejo(movimientoShoot[numFrame],true).getWidth();
                alto = espejo(movimientoShoot[numFrame],true).getHeight();
                parado = false;
                break;
            case "up":
                ancho = espejo(movimientoUp[numFrame],true).getWidth();
                alto = espejo(movimientoUp[numFrame],true).getHeight();
                parado = false;
                break;
        }
        if (parado) {
            float x = posX;
            float y = suelo;
            rectangulos[0] = new RectF(
                    (int) x + ancho / 3,
                    (int) y - (alto - alto / 8),
                    (int) x + (ancho - ancho / 3),
                    (int) y - alto / 2
            );
            rectangulos[1] = new RectF(
                    (int) x + ancho / 4,
                    (int) y - alto / 2,
                    (int) x + (ancho - ancho / 4),
                    (int) y
            );
        }else {
            float x = posX;
            float y = suelo;
            rectangulos[0] = new RectF(
                    (int) x + ancho / 3,
                    (int) y - (alto - alto / 8),
                    (int) x + (ancho - ancho / 3),
                    (int) y - alto / 2
            );
            rectangulos[1] = new RectF(
                    (int) x + ancho / 6,
                    (int) y - alto / 2,
                    (int) x + (ancho - ancho / 6),
                    (int) y
            );
        }
    }

    /***
     * Actualizamos la física de los elementos en pantalla
     */
    public void actualizarFisica(String movimiento) {
        switch (movimiento){
            case "avanceFrame":
                numFrame++;
                if (numFrame >= movimientoX.length) numFrame = 0;
                break;
            case "avanceX":
                posX += getPixels(3f);
                setRectangulos("movimientoX");
                break;
            case "retrocesoFrame":
                numFrame++;
                if (numFrame > movimientoX.length-1) numFrame = 0;
                break;
            case "retrocesoX":
                posX-=getPixels(3f);
                setRectangulos("movimientoXespejo");
                break;
            case "quieto":
                numFrame++;
                if (numFrame >= movimientoQuieto.length) numFrame = 0;
                setRectangulos("quieto");
                break;
            case "disparoLat":
                numFrame++;
                if (numFrame >= movimientoShoot.length) numFrame = 0;
                setRectangulos("shoot");
                break;
            case "disparoUp":
                numFrame++;
                if (numFrame >= movimientoUp.length) numFrame = 0;
                setRectangulos("up");
                break;
            case "muerte":
                if(muriendo)numFrame++;
                if (numFrame >= movimientoDead.length-2 && muriendo){
//                    numFrame = 0;
                    muriendo=false;
                }
        }
    }

    /***
     * Función que guarda los datos en preferencias
     */


    /***
     * Dibujamos los elementos en pantalla
     * @param canvas Lienzo sobre el que dibujar
     */
    public void dibujar(Canvas canvas, String dibujo, boolean derecha) throws Exception{
        switch (dibujo){
            case "haciaAdelante":
                canvas.drawBitmap(movimientoX[numFrame],posX, (suelo - movimientoX[numFrame].getHeight()), null);
                break;
            case "haciaAtras":
                canvas.drawBitmap(espejo(movimientoX[numFrame],true),posX, (suelo - movimientoX[numFrame].getHeight()), null);
                break;
            case "quieto":
                if (derecha) {
                    canvas.drawBitmap(movimientoQuieto[numFrame],posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }else{
                    canvas.drawBitmap(espejo(movimientoQuieto[numFrame],true),posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }
                break;
            case "disparoLat":
                if (derecha) {
                    canvas.drawBitmap(movimientoShoot[numFrame],posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }else{
                    canvas.drawBitmap(espejo(movimientoShoot[numFrame],true),posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }
                break;
            case "disparoUp":
                if (derecha) {
                    canvas.drawBitmap(movimientoUp[numFrame],posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }else{
                    canvas.drawBitmap(espejo(movimientoUp[numFrame],true),posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }
                break;
            case "muerte":
                if (derecha) {
                    canvas.drawBitmap(movimientoDead[numFrame],posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }else{
                    canvas.drawBitmap(espejo(movimientoDead[numFrame],true),posX, (suelo - movimientoX[numFrame].getHeight()), null);
                }
                break;
        }
    }

    /***
     * función que devuelve el rectangulo de colisión del personaje
     * @return rectangulo de colisión
     */
    protected RectF[] getRectangulos(){
        return rectangulos;
    }
}
