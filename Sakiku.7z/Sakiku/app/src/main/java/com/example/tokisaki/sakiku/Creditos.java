package com.example.tokisaki.sakiku;

/**
 * Created by Tokisaki on 15/04/2018.
 */

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.MotionEvent;

/***
 * Escena que contiene los créditos del juego
 */
public class Creditos extends Escenas{

    private Typeface letras = Typeface.createFromAsset(context.getAssets(), "amburegul.ttf"); // fuente externa
    private Typeface faw = Typeface.createFromAsset(context.getAssets(), "fontawesome-webfont.ttf"); // fuente externa
    private Paint p,l; // pinceles para el dibujo de las fuentes externas
    private StaticLayout layoutDescripcion; // Layout contenedor de texto
    private TextPaint pDescripcion; // Pincel para escritura
    private String creditos; // Variable que recogerá "creditos" de strings.xml
    private String creditosTexto; // Variable que recogerá "creditosTexto" de strings.xml
    /***
     * Constructor de la clase
     * @param numEscena numero de la escena
     * @param context contexto de la aplicación
     * @param anchoPantalla ancho de la pantalla del dispositivo donde se ejecita la aplicación
     * @param altoPantalla alto de la pantalla del dispositivo donde se ejecita la aplicación
     */
    public Creditos(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla);
        inicializar();
    }

    /***
     * función que inicializa los elementos de la pantalla
     */
    private void inicializar(){
        /*creditos = context.getResources().getString(R.string.creditosTitulo);
        agradecimientos = context.getResources().getString(R.string.agredecimientos);
        creditosTexto = context.getResources().getString(R.string.creditosTexto);
        agradecimientosTexto = context.getResources().getString(R.string.agredecimientosTexto);*/
        this.pDescripcion = new TextPaint();
        this.pDescripcion.setColor(Color.BLACK);
        this.pDescripcion.setTextSize(getPixels(30));
        this.pDescripcion.setTextAlign(Paint.Align.LEFT);
        pDescripcion.setTypeface(faw);
        l=new Paint();
        l.setColor(Color.BLACK);
        l.setTextSize(getPixels(45));
        l.setTypeface(letras);
        p=new Paint();
        p.setColor(Color.BLACK);
        p.setTextSize(getPixels(40));
        p.setTypeface(faw);
    }

    /***
     * Dibujamos los elementos en pantalla
     * @param c Lienzo sobre el que dibujar
     */
    public void dibujar (Canvas c){
        c.drawBitmap(libro,0,0,null);
        this.layoutDescripcion = new StaticLayout(creditosTexto, pDescripcion,
                anchoPantalla, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false);
        this.layoutDescripcion.draw(c);
        c.drawText(": "+ creditos,0+getPixels(50),layoutDescripcion.getHeight()+getPixels(100),l);

    }

    /***
     * Actualizamos la física de los elementos en pantalla
     */
    public void actualizarFisica(){
        super.actualizarFisica();

    }

    /***
     * Registra las pulsaciones en pantalla
     * @param event Tipo de pulsación
     * @return numero de la escena actual
     */
    public int onTouchEvent(MotionEvent event){
        super.onTouchEvent(event);
        switch (event.getAction()) {
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                return 1 ;
        }
        return numEscena;
    }
}

