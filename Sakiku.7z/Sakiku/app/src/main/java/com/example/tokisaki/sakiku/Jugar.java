package com.example.tokisaki.sakiku;

/**
 * Created by Tokisaki on 15/04/2018.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Vibrator;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

import static android.content.Context.VIBRATOR_SERVICE;

/***
 * Clase que ejecuta los elementos relacionados con el juego , así como el juego en sí
 */
public class Jugar extends Escenas{

    private Typeface faw = Typeface.createFromAsset(context.getAssets(), "fontawesome-webfont.ttf"); // Fuente externa
    private Typeface letras = Typeface.createFromAsset(context.getAssets(), "amburegul.ttf"); // Fuente externa
    private Personaje robot; // instancia de la clase Personaje
    private PointF posicionBala; // posicion en la que esta situda la bala
    private long cambioAstro; // tiempo en el que se cambia entre el sol y la luna
    private long inicioAstro; // tiempo actual en el que se encuentra el sol o la luna
    private long finAstro; // tiempo final tanto del sol como de la luna
    private long astroX = 0; // posición en el eje x del sol o la luna
    private long cambioCiclo; // Tiempo en el que el sol o la luna cambian de imagen
    private long inicio; // tiempo actual
    private long fin; // tiempo final de una calculo
    private long tiempoDibujo; // indica el intervalo de tiempo en el que se dibuja en pantalla
    private long tiempoMove; // indica el intervalo de tiempo en el que se actualizan los frames
    private boolean comienzoAstro = true; // booleano que indica si el sol o la luna estan en sus fases iniciales o finales
    private boolean comenzo = false; // booleano que indica si el juego ha comenzado
    private boolean esDia = true; // indica si es de día o no
    private boolean esNoche = false; // indica si es de noche o no
    private boolean avance = false; // indica si el personaje esta avanzanado
    private boolean retroceso = false; // indica si el personaje esta retrocediendo
    private boolean dispararUp = false; // indica si el personaje esta realizando la acción de disparo vertical
    private boolean dispararLat = false; // indica si el personaje esta realizando la acción de disparo horizontal
    private boolean muerte = false; // booleano que indica si el personaje ha muerto
    private boolean derecha = true; // booleano que indica si el personaje esta mirando hacía la derecha
    private boolean record; // booleana que indica si se ha batido un record
    protected static boolean pause = false; // booleano que indica si el juego esta en pause
    private boolean onemin = false; // booleano que se activa al minuto de juego y permite la entrada de la Bola 1
    private Bitmap luna; // imagen de la luna
    private Bitmap lunaFinal;// imagen de la luna en su ciclo final e inicial
    private Bitmap astro; // imagen que se esta mostrando en pantalla, de la luna o el sol
    private Bitmap fondo; // imagen del capitolio
    private Bitmap nubes; // imagen dee las nubes
    private Bitmap sol; // imagen del sol
    private Bitmap solFinal; // imagen del sol en su ciclo final e inicial
    private Bitmap city; // imagen de la ciudad
    private Bitmap estrellas; // imagen de las estrellas
    private Bitmap suelo; // imagen del cesped
    private Bitmap btnAvz; // imagen para el boton de acanzar
    private Bitmap btnRetrocede; // imagen para el boton de retroceder
    private Bitmap disparo; // imagen para el botón de disparar
    private ArrayList<Flecha> flechas; // lista con las balas que hay en pantalla
    private ArrayList<Bola1> dobles; // lista de enemigos referentes al tipo Bola 1 cuando recibe un impacto y se divide
    private ArrayList<Bolas> bolas; // Lista de enemigos en pantalla
    private int tickFrame = 80; // tiempo de refresco de pantalla para los frames de movimiento del personaje
    private int numEnemigos = 1; // número máximo de enemigos en pantalla
    private int postI1,postI2; // Posicion de las nubes para hacer el efecto parallax
    private int tickDisparoFrame = 40; // tiempo de refresco de pantalla para los frames del disparo del personaje
    private int puntuacion = 0; // puntuación conseguida
    private int tickMove = 10; // tiempo de refresco de pantalla para el movimento sobre el eje X del personaje
    private int v; // volumen de la música
    private int pasear = 0; // numero que calcula cada cuantos frames suena el sonido de las pisadas
    private float multiplicador = 1; // numero que se le va a pasar a la bolas para que suban la velocidad y por ende la dificultad
    private Rect pausa; // boton de pausa
    private Rect parar; // rectangulo que se dibuja sobre toda la pantalla al pulsar el botón de pausa
    private Rect yes; // Boton para salir del juego una vez pulsado pausa
    private Rect no; // botón para regresar al juego despues de haber pulsado pausa
    private String declaracionMuerte; // String que se muestra una vez muere el personaje
    private String pregunta; // String que se muestra cuando pulsas pausa y te pregunta si desas salir
    private String paro; // icono de pausa
    private String si; // String con la palabra "si" mostrado como respuesta a la pregunta si deseas salir durante la pausa
    private String nop; // String con la palabra "no" mostrado como respuesta a la pregunta si deseas salir durante la pausa
    private Paint start; // Pincel que pinta la pantalla de negro
    private Paint p,l; // pinceles para las fuentes externas
    private Comparator<Integer> comparador = Collections.reverseOrder(); // parametro que ordena de manera inversa una lista
    private int cielo; // establece el color del cielo
    private int sol1 = Color.MAGENTA; // color del cielo para el primer ciclo del sol
    private int sol2 = Color.CYAN; // color del cielo para el segunco ceclo del sol
    private int luna1 = Color.BLUE; // color del cielo para el primer ciclo de la luna
    private int luna2 = Color.BLACK; // color del cielo para el segundo ciclo de la luna

    /***
     * Constructor de la clase
     * @param numEscena numero de la escena
     * @param context contexto de la aplicación
     * @param anchoPantalla ancho de la pantalla del dispositivo donde se ejecita la aplicación
     * @param altoPantalla alto de la pantalla del dispositivo donde se ejecita la aplicación
     */
    public Jgar(int numEscena, Context context, int anchoPantalla, int altoPantalla) {
        super(numEscena, context, anchoPantalla, altoPantalla,info);
        inicializar();
        if(info.musica){
            Inicio.mediaPlayer.stop();
            Inicio.musicaJuego.start();
        }
        flechas = new ArrayList<>();
        dobles = new ArrayList<>();
        bolas = new ArrayList<>();
        postI1 = 0;
        postI2 = nubes.getWidth();
        robot = new Personaje(context,(altoPantalla-(btnAvz.getHeight()*3/4)),info);
        tiempoDibujo=System.currentTimeMillis();
        tiempoMove = System.currentTimeMillis();
        comenzo = true;
        cambioCiclo = System.currentTimeMillis() + 30000;
        astroX = anchoPantalla;
        finAstro = System.nanoTime() + 100000;
        cambioAstro = System.currentTimeMillis() + 5000;
        v= audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        record = false;
        cielo = sol1;
    }

    /***
     * Inicializa los elementos necesarios para la clase
     */
    private void inicializar(){
        btnAvz= BitmapFactory.decodeResource(context.getResources(), R.drawable.signal);
        btnAvz = escalaAnchura(btnAvz,getPixels(120));
        btnRetrocede= BitmapFactory.decodeResource(context.getResources(), R.drawable.signal);
        btnRetrocede = espejo(btnRetrocede,true);
        btnRetrocede = escalaAnchura(btnRetrocede,getPixels(120));
        disparo= BitmapFactory.decodeResource(context.getResources(), R.drawable.senal);
        disparo = escalaAnchura(disparo,getPixels(80));
        fondo= BitmapFactory.decodeResource(context.getResources(),R.drawable.capitolio);
        fondo=Bitmap.createScaledBitmap(fondo,getPixels(380),getPixels(400),true);
        city= BitmapFactory.decodeResource(context.getResources(),R.drawable.blackcity);
        city=Bitmap.createScaledBitmap(city,anchoPantalla,altoPantalla,true);
        suelo= BitmapFactory.decodeResource(context.getResources(),R.drawable.grass);
        suelo=Bitmap.createScaledBitmap(suelo,getPixels(anchoPantalla/2),getPixels(altoPantalla/2+getPixels(100)),true);
        sol= BitmapFactory.decodeResource(context.getResources(),R.drawable.sol);
        sol=Bitmap.createScaledBitmap(sol,getPixels(150),getPixels(150),true);
        solFinal = BitmapFactory.decodeResource(context.getResources(), R.drawable.solfinal);
        solFinal = Bitmap.createScaledBitmap(solFinal, getPixels(150), getPixels(150), true);
        luna = BitmapFactory.decodeResource(context.getResources(), R.drawable.luna);
        luna = Bitmap.createScaledBitmap(luna, getPixels(150), getPixels(150), true);
        lunaFinal = BitmapFactory.decodeResource(context.getResources(), R.drawable.lunafinal);
        lunaFinal = Bitmap.createScaledBitmap(lunaFinal, getPixels(150), getPixels(150), true);
        nubes= BitmapFactory.decodeResource(context.getResources(),R.drawable.nubes);
        estrellas= BitmapFactory.decodeResource(context.getResources(),R.drawable.estrellado);
        estrellas=Bitmap.createScaledBitmap(estrellas,anchoPantalla,altoPantalla/2,true);
        astro = solFinal;
        pausa = new Rect(0,0,0+getPixels(50),0+getPixels(50));
        paro =  context.getResources().getString(R.string.pause);
        parar = new Rect(0,0,anchoPantalla,altoPantalla);
        yes = new Rect(anchoPantalla/2-getPixels(100),altoPantalla/2,anchoPantalla/2-getPixels(25),altoPantalla/2+getPixels(50));
        no = new Rect(anchoPantalla/2+getPixels(100),altoPantalla/2,anchoPantalla/2+getPixels(25),altoPantalla/2+getPixels(50));
        pregunta = context.getResources().getString(R.string.preguntaSalir);
        si = context.getResources().getString(R.string.si);
        nop = context.getResources().getString(R.string.no);
        declaracionMuerte = context.getResources().getString(R.string.muerte);
        start = new Paint();
        start.setColor(Color.BLACK);
        p=new Paint();
        p.setColor(Color.RED);
        p.setTextSize(getPixels(50));
        p.setTypeface(faw);
        l=new Paint();
        l.setColor(Color.RED);
        l.setTextSize(getPixels(30));
        l.setTypeface(letras);
    }

    /***
     * Función que aplica visión de espejo a una imagen
     * @param imagen imagen a aplicar la visión
     * @param horizontal Booleano que indica si se plicara c
     * @return
     */
    public Bitmap espejo(Bitmap imagen, Boolean horizontal){
        Matrix matrix = new Matrix();
        if (horizontal) matrix.preScale(-1, 1);
        else matrix.preScale(1, -1);
        return Bitmap.createBitmap(imagen, 0, 0, imagen.getWidth(),
                imagen.getHeight(), matrix, false);
    }


    /***
     * Función que realiza la deteccion de colisiones en el juego
     */
    private void detectaColision() {
        if (bolas.size() >= 1) {
            for (int i = flechas.size() - 1; i >= 0; i--) {
                for (int j = bolas.size() - 1; j >= 0; j--) {
                    if (flechas.get(i).getRectangulo().intersect(bolas.get(j).getRectangulo())) {
                        if (bolas.get(j) instanceof Bola1) {
                            Bola1 b1 = new Bola1(this.context, bolas.get(j).posicion.x - 50, bolas.get(j).posicion.y, anchoPantalla, altoPantalla, 2,multiplicador);
                            Bola1 b2 = new Bola1(this.context, bolas.get(j).posicion.x + 50, bolas.get(j).posicion.y, anchoPantalla, altoPantalla, 2,multiplicador);
                            b1.direccion = -1;
                            b2.direccion = 1;
                            dobles.add(b1);
                            dobles.add(b2);
                            bolas.remove(j);
                            if(info.efectos)efectos.play(sonidoExplosion,v,v,1,0,1 );
                            break;
                        }
                        if (bolas.get(j) instanceof Bola2) {
                            bolas.get(j).vida--;
                            if (bolas.get(j).vida >= 1) {
                                bolas.get(j).eleccionCara(2);
                                if(info.efectos)efectos.play(sonidoExplosion,v,v,1,0,1 );
                            } else {
                                bolas.remove(j);
                                puntuacion += 100;
                                if(info.efectos)efectos.play(sonidoExplosionFinal,v,v,1,0,1 );
                            }
                            flechas.remove(i);
                            break;
                        }
                        if (bolas.get(j) instanceof Bola3) {
                            bolas.remove(j);
                            flechas.remove(i);
                            puntuacion += 200;
                            if(info.efectos)efectos.play(sonidoExplosionFinal,v,v,1,0,1 );
                        }
                    }
                }
            }
            if (dobles.size() >= 1) {
                for (int i = flechas.size() - 1; i >= 0; i--) {
                    for (int j = dobles.size() - 1; j >= 0; j--) {
                        if (flechas.get(i).getRectangulo().intersect(dobles.get(j).getRectangulo())) {
                            if (dobles.get(j).vida > 1) {
                                Bola1 b1 = new Bola1(this.context, dobles.get(j).posicion.x - 50, dobles.get(j).posicion.y, anchoPantalla, altoPantalla, 1,multiplicador);
                                Bola1 b2 = new Bola1(this.context, dobles.get(j).posicion.x + 50, dobles.get(j).posicion.y, anchoPantalla, altoPantalla, 1,multiplicador);
                                b1.direccion = -1;
                                b2.direccion = 1;
                                dobles.add(b1);
                                dobles.add(b2);
                                dobles.remove(j);
                                flechas.remove(i);
                                if(info.efectos)efectos.play(sonidoExplosion,v,v,1,0,1 );
                            } else {
                                dobles.remove(j);
                                flechas.remove(i);
                                if(info.efectos)efectos.play(sonidoExplosionFinal,v,v,1,0,1 );
                            }
                            break;
                        }
                    }
                }
            }

            for (Bolas b : bolas){
                if(b.getRectangulo().intersect(robot.getRectangulos()[0]) || b.getRectangulo().intersect(robot.getRectangulos()[1])){
                    muertePersonaje();
                    break;
                }
            }
            for (Bola1 b : dobles){
                if(b.getRectangulo().intersect(robot.getRectangulos()[0]) || b.getRectangulo().intersect(robot.getRectangulos()[1])){
                    muertePersonaje();
                    break;
                }
            }
        }
    }

    /***
     * Funcion que realiza todas las acciones que se dan en el personaje cuando muere
     */
    private void muertePersonaje(){
        muerte = true;
        robot.numFrame = 0;
        robot.muriendo = true;
        Inicio.musicaJuego.stop();
        if(info.efectos)efectos.play(gameover, v, v, 1, 0, 1);
        if(info.vibrar) {
            Vibrator mVibrator = (Vibrator) context.getSystemService(VIBRATOR_SERVICE);
            mVibrator.vibrate(1000);
        }
    }

    /***
     * Funcion que cambia entre el sol y la luna
     */
    private void cambiarCiclo(){
        if(esDia){
            esDia=false;
            esNoche=true;
            astro = lunaFinal;
            cielo = luna1;
            numEnemigos++;
        }else {
            esNoche = false;
            esDia = true;
            astro = solFinal;
            multiplicador++;
            onemin = true;
        }
        cambioAstro = System.currentTimeMillis() + 5000;
        finAstro = System.nanoTime() + 100000;
        astroX = anchoPantalla;
        comienzoAstro = true;
    }

    /***
     * Función que cambia las imagenes del sol y la luna en sus distintos ciclos
     */
    private void cambiarAstro(){
        inicioAstro = System.nanoTime();
        if(inicioAstro > finAstro){
            if(System.currentTimeMillis() > cambioAstro){
                if(comienzoAstro){
                    comienzoAstro = false;
                    if(esDia){
                        astro = sol;
                        cielo = sol2;
                    }
                    if(esNoche){
                        astro = luna;
                        cielo = luna2;
                    }
                    cambioAstro = System.currentTimeMillis() + 15000;
                }else{
                    if(esDia){
                        astro = solFinal;
                        cielo = sol1;
                    }
                    if(esNoche) {
                        astro = lunaFinal;
                        cielo = luna1;
                    }
                    cambioAstro = System.currentTimeMillis() + 15000;
                }
            }
            astroX -= anchoPantalla / 600;
            finAstro = System.nanoTime() + 100000;
        }
    }

    /***
     * Actualizamos la física de los elementos en pantalla
     */
    public void actualizarFisica() {
        if(!pause) {
            if (!muerte) {
                postI1 -= getPixels(3);
                postI2 -= getPixels(3);
                if (postI1 + nubes.getWidth() < 0) {
                    postI1 = postI2 + nubes.getWidth();
                }

                if (postI2 + nubes.getWidth() < 0) {
                    postI2 = postI1 + nubes.getWidth();
                }
                if (System.currentTimeMillis() > cambioCiclo) {
                    cambiarCiclo();
                    cambioCiclo = System.currentTimeMillis() + 30000;
                }
                cambiarAstro();
                inicio = System.currentTimeMillis();
                if (bolas.size() < numEnemigos && inicio > fin) {
                    bolaAzar();
                    fin = System.currentTimeMillis() + 1000;
                }
                if (bolas.size() >= 1) {
                    for (Bolas bola : bolas) {
                        if (bola instanceof Bola1) {
                            ((Bola1) bola).actualizarFisica();
                        } else if (bola instanceof Bola2) {
                            ((Bola2) bola).actualizarFisica();
                        } else {
                            ((Bola3) bola).actualizarFisica();
                        }
                    }
                }
                if (dobles.size() >= 1) {
                    for (Bola1 bola : dobles) {
                        bola.actualizarFisica();
                    }
                }
                if (comenzo) {
                    if (dispararLat || dispararUp) { // bool para controlar las salidas
                        if (System.currentTimeMillis() - tiempoDibujo > tickDisparoFrame) {
                            if (dispararLat) {
                                robot.actualizarFisica("disparoLat");
                                if (robot.numFrame == 0) {
                                    if (derecha) {
                                        posicionBala = new PointF(robot.rectangulos[1].centerX() + robot.rectangulos[1].width() / 2
                                                , robot.suelo - robot.alto / 2);
                                    } else {
                                        posicionBala = new PointF(robot.rectangulos[1].centerX() - robot.rectangulos[1].width() / 2
                                                , robot.suelo - robot.alto / 2);
                                    }
                                    flechas.add(new Flecha(context, posicionBala, true, derecha));
                                    if(info.efectos)efectos.play(sonidoDisparo, v, v, 1, 0, 1);
                                    dispararLat = false;
                                    robot.numFrame = 0;
                                }
                            } else {
                                robot.actualizarFisica("disparoUp");
                                if (robot.numFrame == 0) {
                                    posicionBala = new PointF(robot.rectangulos[0].centerX(), robot.suelo - robot.alto);
                                    flechas.add(new Flecha(context, posicionBala, false, derecha));
                                    if(info.efectos)efectos.play(sonidoDisparo, v, v, 1, 0, 1);
                                    dispararUp = false;
                                    robot.numFrame = 0;
                                }
                            }
                            tiempoDibujo = System.currentTimeMillis();
                        }
                    } else {
                        if (System.currentTimeMillis() - tiempoDibujo > tickFrame) {
                            pasear++;
                            if (avance && robot.posX < anchoPantalla - 100) {
                                robot.actualizarFisica("avanceFrame");
                                if(info.efectos)if (pasear % 4 == 0) efectos.play(pasos, v, v, 1, 0, 1);
                            } else if (retroceso && robot.posX > 1) {
                                robot.actualizarFisica("retrocesoFrame");
                                if(info.efectos)if (pasear % 4 == 0) efectos.play(pasos, v, v, 1, 0, 1);
                            } else {
                                robot.actualizarFisica("quieto");
                                pasear = 0;
                            }
                            tiempoDibujo = System.currentTimeMillis();
                        }
                    }
                }
                if (System.currentTimeMillis() - tiempoMove > tickMove) {
                    if (avance && robot.posX < anchoPantalla - 100) {
                        robot.actualizarFisica("avanceX");
                    } else if (retroceso && robot.posX > 1) {
                        robot.actualizarFisica("retrocesoX");
                    }
                    tiempoMove = System.currentTimeMillis();
                } else if (dispararUp) {
                }
                for (Flecha nave : flechas) {
                    nave.actualizarFisica();
                    if (nave.posicion.y < 0 - nave.movimientoBala[nave.numFrame].getHeight() || nave.posicion.x > anchoPantalla + nave.movimientoBala[nave.numFrame].getWidth()
                            || nave.posicion.x < 0 - nave.movimientoBala[nave.numFrame].getWidth()) {
                        flechas.remove(nave);
                        break;
                    }
                }
                detectaColision();
            }else{
                if (System.currentTimeMillis() - tiempoDibujo > tickFrame && robot.muriendo ==true) {
                    robot.actualizarFisica("muerte");
                    tiempoDibujo = System.currentTimeMillis();
                    if(!record){
                        info.records.add(puntuacion);
                        Collections.sort(info.records,comparador);
                        record = true;
                    }
                }
            }
        }
    }

    /***
     * Dibujamos los elementos en pantalla
     * @param canvas Lienzo sobre el que dibujar
     */
    public void dibujar(Canvas canvas) {
        try {
            if(!pause) {
                if(!muerte) {
                    canvas.drawColor(cielo);
                    canvas.drawBitmap(suelo, 0, altoPantalla/2+getPixels(100), null);
                    if (esNoche) canvas.drawBitmap(estrellas, 0, 0, null);
                    canvas.drawBitmap(astro, astroX, 0, null);
                    if (esDia) {
                        canvas.drawBitmap(nubes, postI1, 0, null);
                        canvas.drawBitmap(nubes, postI2, 0, null);
                    }
                    canvas.drawRect(pausa, pBoton);
                    canvas.drawText(paro, pausa.centerX() - pausa.width() / 2, pausa.centerY() + pausa.height() / 2, p);
                    canvas.drawBitmap(city, 0, altoPantalla - (fondo.getHeight() + btnAvz.getHeight() + fondo.getWidth() / 2), null);
                    canvas.drawBitmap(fondo, 0, altoPantalla - (fondo.getHeight() + btnAvz.getHeight()), null);
                    canvas.drawText(""+puntuacion, 0+getPixels(10), pausa.height()+ getPixels(30), l);
                    if (bolas.size() >= 1) {
                        for (Bolas bola : bolas) {
                            if (bolas.size() >= 1) {
                                bola.dibujar(canvas);
                            }
                        }
                    }
                    if (dobles.size() >= 1) {
                        for (Bola1 bola : dobles) {
                            if (dobles.size() >= 1) {
                                bola.dibujar(canvas);
                            }
                        }
                    }
                    if (dispararLat) {
                        robot.dibujar(canvas, "disparoLat", derecha);
                    } else if (dispararUp) {
                        robot.dibujar(canvas, "disparoUp", derecha);
                    } else if (avance) {
                        robot.dibujar(canvas, "haciaAdelante", derecha);
                    } else if (retroceso) {
                        robot.dibujar(canvas, "haciaAtras", derecha);
                    } else {
                        robot.dibujar(canvas, "quieto", derecha);
                    }
                    canvas.drawBitmap(btnRetrocede, 0, altoPantalla - btnAvz.getHeight(), null);
                    canvas.drawBitmap(btnAvz, btnAvz.getWidth(), altoPantalla - btnRetrocede.getHeight(), null);
                    canvas.drawBitmap(disparo, anchoPantalla - disparo.getWidth(), altoPantalla - disparo.getHeight(), null);
                    for (Flecha nave : flechas) {
                        nave.dibujar(canvas);
                    }
                }else{
                    canvas.drawRect(parar, start);
                    canvas.drawText(declaracionMuerte,0+getPixels(50),altoPantalla/2,l);
                    canvas.drawText(""+puntuacion, 0+getPixels(10), pausa.height()+ getPixels(30), l);
                    robot.dibujar(canvas, "muerte", derecha);
                }
            }else {
                canvas.drawRect(parar, start);
                canvas.drawText(pregunta,0+getPixels(5),0+getPixels(80),l);
                canvas.drawRect(yes, pBoton);
                canvas.drawText(si, yes.centerX() - yes.width() / 2, yes.centerY() + pausa.height() / 2, l);
                canvas.drawRect(no, pBoton);
                canvas.drawText(nop, no.centerX() - no.width() / 2, no.centerY() + no.height() / 2, l);
            }
        } catch (Exception e) {

        }
    }

    /***
     * Registra las pulsaciones en pantalla
     * @param event Tipo de pulsación
     * @return numero de la escena actual
     */
    @Override
    public int onTouchEvent(MotionEvent event) {
        int accion = event.getActionMasked();
        float x = event.getX(), y = event.getY();
        switch (accion) {
            case MotionEvent.ACTION_DOWN:
                if(!pause) {
                    if(!muerte) {
                        if (x > btnRetrocede.getWidth() && x < btnRetrocede.getWidth() + btnAvz.getWidth()
                                && y > altoPantalla - btnRetrocede.getHeight()) {
                            avance = true;
                            derecha = true;
                        } else if (x > 0 && x < btnRetrocede.getWidth() && y > altoPantalla - btnRetrocede.getHeight()) {
                            retroceso = true;
                            derecha = false;
                        } else if (x > anchoPantalla - disparo.getWidth() && x < anchoPantalla &&
                                y > (altoPantalla - disparo.getHeight())) {
                            dispararUp = true;
                            robot.numFrame = 0;
                        }
                        if (pausa.contains((int) event.getX(), (int) event.getY())) {
                            pause = true;
                            Inicio.musicaJuego.pause();
                        }
                    }else {
                        Inicio.musicaJuego.stop();
                        Inicio.mediaPlayer.start();
                        return 1;
                    }
                }
                else {
                    if (yes.contains((int) event.getX(), (int) event.getY())) {
                        Inicio.mediaPlayer.start();
                        return 1;
                    }else{
                        pause = false;
                        Inicio.musicaJuego.start();
                    }
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                if(!pause) {
                    if (event.getPointerCount() > 0) {
                        for (int i = 0; i < event.getPointerCount(); i++) {
                            if (i > 0) {
                                float x2 = event.getX(i);
                                float y2 = event.getY(i);
                                if (x2 > anchoPantalla - disparo.getWidth() && x < anchoPantalla &&
                                        y2 > altoPantalla - disparo.getHeight()) {
                                    avance = false;
                                    retroceso = false;
                                    dispararLat = true;
                                    robot.numFrame = 0;
                                }
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if(!pause) {
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        x = event.getX(i);
                        y = event.getY(i);
                        if (retroceso) {
                            if (x < 0 || x > btnRetrocede.getWidth() || y < altoPantalla - btnRetrocede.getHeight()) {
                                retroceso = false;
                                derecha = false;
                            }
                        } else if (avance) {
                            if (x < btnRetrocede.getWidth() || x > btnRetrocede.getWidth() + btnAvz.getWidth()
                                    || y < altoPantalla - btnRetrocede.getHeight()) {
                                avance = false;
                                derecha = true;
                            }
                        } else if (!avance || !retroceso) {
                            if (x > 0 && x < btnRetrocede.getWidth() && y > altoPantalla - btnRetrocede.getHeight()) {
                                retroceso = true;
                                derecha = false;
                            }
                            if (x > btnRetrocede.getWidth() && x < btnRetrocede.getWidth() + btnAvz.getWidth()
                                    && y > altoPantalla - btnRetrocede.getHeight()) {
                                derecha = false;
                                avance = true;
                            }

                        } else if (!retroceso) {
                            if (x > btnRetrocede.getWidth() && x < btnRetrocede.getWidth() + btnAvz.getWidth()
                                    && y > altoPantalla - btnAvz.getHeight()) {
                                avance = true;
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
                if(!pause) {
                    if (avance) {
                        derecha = true;
                    } else if (retroceso) {
                        derecha = false;
                    }
                    avance = false;
                    retroceso = false;
                }
                break;
        }

        return numEscena;
    }

    /***
     * Funcion que crea una bola al azar entre sus 3 tipos
     */
    private void bolaAzar(){
        int azar = new Random().nextInt(100) + 1;
        if(onemin) {
            if (azar < 50) {
                bolas.add(new Bola2(context, new Random().nextFloat() * anchoPantalla, 0, anchoPantalla, (altoPantalla - disparo.getHeight()), 3, multiplicador));
                if (info.efectos) efectos.play(alien, v, v, 1, 0, 1);
            } else if (azar >= 50 && azar < 60) {
                Bola1 bola = new Bola1(context, new Random().nextFloat() * anchoPantalla, 0, anchoPantalla, (altoPantalla - disparo.getHeight()), 3, multiplicador);
                if (new Random().nextFloat() > 0.5f) {
                    bola.direccion = 1;
                } else {
                    bola.direccion = -1;
                }
                bolas.add(bola);
                if (info.efectos) efectos.play(sonidoEntrada, v, v, 1, 0, 1);
            } else if (azar >= 60) {
                bolas.add(new Bola3(context, new Random().nextFloat(), 0, anchoPantalla, (altoPantalla - disparo.getHeight()), 1, multiplicador));
                if (info.efectos) efectos.play(alienEntrada, v, v, 1, 0, 1);
            }
        }else{
            if (azar < 60) {
                bolas.add(new Bola2(context, new Random().nextFloat() * anchoPantalla, 0, anchoPantalla, (altoPantalla - disparo.getHeight()), 3, multiplicador));
                if (info.efectos) efectos.play(alien, v, v, 1, 0, 1);
            }else {
                bolas.add(new Bola3(context, new Random().nextFloat(), 0, anchoPantalla, (altoPantalla - disparo.getHeight()), 1, multiplicador));
                if (info.efectos) efectos.play(alienEntrada, v, v, 1, 0, 1);
            }
        }
    }
}



